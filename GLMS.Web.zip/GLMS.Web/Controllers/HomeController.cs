using System.Diagnostics;
using GLMS.Web.Models;
using GLMS.Web.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace GLMS.Web.Controllers;

public sealed class HomeController(IGlmsApiClient apiClient) : Controller
{
    public async Task<IActionResult> Index(CancellationToken cancellationToken)
    {
        var dashboard = await apiClient.GetDashboardAsync(cancellationToken);
        return View(new DashboardViewModel
        {
            ClientCount = dashboard.ClientCount,
            ActiveContractCount = dashboard.ActiveContractCount,
            OpenRequestCount = dashboard.OpenRequestCount,
            RecentRequests = dashboard.RecentRequests
        });
    }

    public IActionResult Privacy() => View();

    [AllowAnonymous]
    public IActionResult Unavailable() =>
        View(new ApiUnavailableViewModel("The GLMS API is currently unavailable. Please try again shortly."));

    [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
    [AllowAnonymous]
    public IActionResult Error() =>
        View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
}
