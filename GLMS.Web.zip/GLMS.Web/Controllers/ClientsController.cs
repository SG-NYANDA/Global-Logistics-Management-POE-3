using GLMS.Contracts;
using GLMS.Web.Models;
using GLMS.Web.Services;
using Microsoft.AspNetCore.Mvc;

namespace GLMS.Web.Controllers;

public sealed class ClientsController(IGlmsApiClient apiClient) : Controller
{
    public async Task<IActionResult> Index(CancellationToken cancellationToken) =>
        View(await apiClient.GetClientsAsync(cancellationToken));

    public IActionResult Create() => View(new ClientCreateViewModel());

    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Create(ClientCreateViewModel model, CancellationToken cancellationToken)
    {
        if (!ModelState.IsValid)
        {
            return View(model);
        }

        try
        {
            await apiClient.CreateClientAsync(new CreateClientRequest
            {
                Name = model.Name.Trim(),
                ContactDetails = model.ContactDetails.Trim(),
                Region = model.Region.Trim()
            }, cancellationToken);
        }
        catch (ApiClientException exception)
        {
            ModelState.AddModelError(string.Empty, exception.Message);
            return View(model);
        }

        TempData["Notice"] = "Client added.";
        return RedirectToAction(nameof(Index));
    }
}
