using System.Security.Claims;
using GLMS.Contracts;
using GLMS.Web.Models;
using GLMS.Web.Services;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace GLMS.Web.Controllers;

[AllowAnonymous]
public sealed class AccountController(IAccountApiClient accountApiClient) : Controller
{
    [HttpGet]
    public IActionResult Register() => View(new RegisterViewModel());

    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Register(RegisterViewModel model, CancellationToken cancellationToken)
    {
        if (!ModelState.IsValid)
        {
            return View(model);
        }

        var email = model.Email.Trim();
        try
        {
            await accountApiClient.RegisterAsync(new RegisterAccountRequest
            {
                Email = email,
                Password = model.Password
            }, cancellationToken);
        }
        catch (ApiClientException exception) when (exception.StatusCode == System.Net.HttpStatusCode.Conflict)
        {
            TempData["VerificationEmail"] = email;
            TempData["Notice"] = "If the address belongs to an unverified account, you can request a verification code.";
            return RedirectToAction(nameof(Verify));
        }
        catch (ApiClientException exception) when (exception.StatusCode == System.Net.HttpStatusCode.ServiceUnavailable)
        {
            TempData["VerificationEmail"] = email;
            TempData["Error"] = exception.Message;
            return RedirectToAction(nameof(Verify));
        }
        catch (ApiClientException exception)
        {
            ModelState.AddModelError(string.Empty, exception.Message);
            return View(model);
        }

        TempData["VerificationEmail"] = email;
        TempData["Notice"] = "A verification code has been sent. It expires in 10 minutes.";
        return RedirectToAction(nameof(Verify));
    }

    [HttpGet]
    public IActionResult Verify()
    {
        var email = TempData.Peek("VerificationEmail") as string ?? string.Empty;
        return View(new VerifyEmailCodeViewModel { Email = email });
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Verify(VerifyEmailCodeViewModel model, CancellationToken cancellationToken)
    {
        if (!ModelState.IsValid)
        {
            return View(model);
        }

        try
        {
            var token = await accountApiClient.VerifyAsync(new VerifyAccountRequest
            {
                Email = model.Email.Trim(),
                Code = model.Code
            }, cancellationToken);
            await SignInAsync(token, isPersistent: false);
        }
        catch (ApiClientException exception) when (exception.StatusCode == System.Net.HttpStatusCode.BadRequest)
        {
            ModelState.AddModelError(string.Empty, exception.Message);
            return View(model);
        }

        TempData["Notice"] = "Your email is verified. Welcome to GLMS.";
        return RedirectToAction("Index", "Home");
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> ResendVerification(
        ResendVerificationViewModel model,
        CancellationToken cancellationToken)
    {
        if (ModelState.IsValid)
        {
            try
            {
                await accountApiClient.ResendVerificationAsync(new ResendAccountVerificationRequest
                {
                    Email = model.Email.Trim()
                }, cancellationToken);
                TempData["Notice"] = "If the address belongs to an unverified account, a verification code has been sent.";
            }
            catch (ApiClientException)
            {
                TempData["Notice"] = "If the address belongs to an unverified account, a verification code will be available after the resend interval.";
            }
        }
        else
        {
            TempData["Error"] = "Enter a valid email address to request a verification code.";
        }

        TempData["VerificationEmail"] = model.Email;
        return RedirectToAction(nameof(Verify));
    }

    [HttpGet]
    public IActionResult Login(string? returnUrl = null) =>
        View(new LoginViewModel { ReturnUrl = returnUrl });

    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Login(LoginViewModel model, CancellationToken cancellationToken)
    {
        if (!ModelState.IsValid)
        {
            return View(model);
        }

        AccountTokenResponse token;
        try
        {
            token = await accountApiClient.LoginAsync(new LoginAccountRequest
            {
                Email = model.Email.Trim(),
                Password = model.Password
            }, cancellationToken);
        }
        catch (ApiClientException)
        {
            ModelState.AddModelError(string.Empty,
                "Email or password is incorrect, the account is not verified, or sign-in is temporarily unavailable.");
            return View(model);
        }

        await SignInAsync(token, model.RememberMe);
        if (Url.IsLocalUrl(model.ReturnUrl))
        {
            return LocalRedirect(model.ReturnUrl!);
        }

        return RedirectToAction("Index", "Home");
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Logout()
    {
        await HttpContext.SignOutAsync(CookieAuthenticationDefaults.AuthenticationScheme);
        return RedirectToAction(nameof(Login));
    }

    private async Task SignInAsync(AccountTokenResponse token, bool isPersistent)
    {
        var identity = new ClaimsIdentity(
        [
            new Claim(ClaimTypes.NameIdentifier, token.Email),
            new Claim(ClaimTypes.Name, token.Email),
            new Claim(ClaimTypes.Email, token.Email),
            new Claim(ApiAuthorizationHandler.AccessTokenClaim, token.AccessToken)
        ],
        CookieAuthenticationDefaults.AuthenticationScheme);
        var properties = new AuthenticationProperties { IsPersistent = isPersistent };
        await HttpContext.SignInAsync(
            CookieAuthenticationDefaults.AuthenticationScheme,
            new ClaimsPrincipal(identity),
            properties);
    }
}
