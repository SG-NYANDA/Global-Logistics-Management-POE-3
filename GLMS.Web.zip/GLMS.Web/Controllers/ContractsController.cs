using GLMS.Contracts;
using GLMS.Web.Models;
using GLMS.Web.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace GLMS.Web.Controllers;

public sealed class ContractsController(IGlmsApiClient apiClient) : Controller
{
    public async Task<IActionResult> Index(
        ContractStatus? status,
        DateTime? fromDate,
        DateTime? toDate,
        CancellationToken cancellationToken)
    {
        var model = new ContractIndexViewModel
        {
            Contracts = await apiClient.GetContractsAsync(status, fromDate, toDate, cancellationToken),
            Status = status,
            FromDate = fromDate,
            ToDate = toDate
        };
        return View(model);
    }

    public async Task<IActionResult> Create(CancellationToken cancellationToken)
    {
        var model = new ContractCreateViewModel();
        await PopulateClientsAsync(model, cancellationToken);
        return View(model);
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    [RequestSizeLimit(11 * 1024 * 1024)]
    public async Task<IActionResult> Create(ContractCreateViewModel model, CancellationToken cancellationToken)
    {
        if (model.EndDate.Date < model.StartDate.Date)
        {
            ModelState.AddModelError(nameof(model.EndDate), "End date must be on or after the start date.");
        }

        if (!Enum.IsDefined(model.Status))
        {
            ModelState.AddModelError(nameof(model.Status), "Select a valid contract status.");
        }

        if (model.Agreement is null)
        {
            ModelState.AddModelError(nameof(model.Agreement), "Upload the signed PDF agreement.");
        }

        if (!ModelState.IsValid)
        {
            await PopulateClientsAsync(model, cancellationToken);
            return View(model);
        }

        try
        {
            await apiClient.CreateContractAsync(new CreateContractRequest
            {
                Reference = model.Reference.Trim(),
                ServiceLevel = model.ServiceLevel.Trim(),
                StartDate = new DateTimeOffset(DateTime.SpecifyKind(model.StartDate.Date, DateTimeKind.Utc)),
                EndDate = new DateTimeOffset(DateTime.SpecifyKind(model.EndDate.Date, DateTimeKind.Utc)),
                Status = model.Status,
                ClientId = model.ClientId,
                Agreement = model.Agreement!
            }, cancellationToken);
        }
        catch (ApiClientException exception)
        {
            ModelState.AddModelError(string.Empty, exception.Message);
            await PopulateClientsAsync(model, cancellationToken);
            return View(model);
        }

        TempData["Notice"] = "Contract added.";
        return RedirectToAction(nameof(Index));
    }

    public async Task<IActionResult> DownloadAgreement(int id, CancellationToken cancellationToken)
    {
        var agreement = await apiClient.DownloadAgreementAsync(id, cancellationToken);
        return agreement is null
            ? NotFound()
            : File(agreement.Content, "application/pdf", agreement.FileName);
    }

    private async Task PopulateClientsAsync(ContractCreateViewModel model, CancellationToken cancellationToken)
    {
        model.Clients = (await apiClient.GetClientsAsync(cancellationToken))
            .OrderBy(client => client.Name)
            .Select(client => new SelectListItem(client.Name, client.Id.ToString()))
            .ToList();
    }
}
