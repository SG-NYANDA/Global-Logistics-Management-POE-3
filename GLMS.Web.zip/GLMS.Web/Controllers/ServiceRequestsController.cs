using GLMS.Contracts;
using GLMS.Web.Models;
using GLMS.Web.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace GLMS.Web.Controllers;

public sealed class ServiceRequestsController(IGlmsApiClient apiClient) : Controller
{
    public async Task<IActionResult> Index(CancellationToken cancellationToken) =>
        View(await apiClient.GetServiceRequestsAsync(cancellationToken));

    public async Task<IActionResult> Create(CancellationToken cancellationToken)
    {
        var model = new ServiceRequestCreateViewModel();
        await PopulateContractsAsync(model, cancellationToken);
        return View(model);
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Create(ServiceRequestCreateViewModel model, CancellationToken cancellationToken)
    {
        if (!ModelState.IsValid)
        {
            await PopulateContractsAsync(model, cancellationToken);
            return View(model);
        }

        try
        {
            await apiClient.CreateServiceRequestAsync(new CreateServiceRequestRequest
            {
                ContractId = model.ContractId,
                Description = model.Description.Trim(),
                UsdCost = model.UsdCost
            }, cancellationToken);
        }
        catch (ApiClientException exception)
        {
            ModelState.AddModelError(string.Empty, exception.Message);
            await PopulateContractsAsync(model, cancellationToken);
            return View(model);
        }

        TempData["Notice"] = "Service request added.";
        return RedirectToAction(nameof(Index));
    }

    [HttpGet]
    public async Task<IActionResult> CurrentRate(CancellationToken cancellationToken)
    {
        var response = await apiClient.GetCurrentRateAsync(cancellationToken);
        return Json(new { rate = response.Rate });
    }

    private async Task PopulateContractsAsync(ServiceRequestCreateViewModel model, CancellationToken cancellationToken)
    {
        var contracts = await apiClient.GetContractsAsync(
            ContractStatus.Active,
            DateTime.UtcNow.Date,
            DateTime.UtcNow.Date,
            cancellationToken);
        model.Contracts = contracts
            .OrderBy(contract => contract.Reference)
            .Select(contract => new SelectListItem(
                $"{contract.Reference} · {contract.ClientName}",
                contract.Id.ToString()))
            .ToList();
    }
}
