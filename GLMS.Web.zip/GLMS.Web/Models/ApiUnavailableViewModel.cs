namespace GLMS.Web.Models;

public sealed record ApiUnavailableViewModel(string Message);
