using GLMS.Contracts;

namespace GLMS.Web.Services;

public interface IAccountApiClient
{
    Task RegisterAsync(RegisterAccountRequest request, CancellationToken cancellationToken);
    Task<AccountTokenResponse> LoginAsync(LoginAccountRequest request, CancellationToken cancellationToken);
    Task<AccountTokenResponse> VerifyAsync(VerifyAccountRequest request, CancellationToken cancellationToken);
    Task ResendVerificationAsync(ResendAccountVerificationRequest request, CancellationToken cancellationToken);
}
