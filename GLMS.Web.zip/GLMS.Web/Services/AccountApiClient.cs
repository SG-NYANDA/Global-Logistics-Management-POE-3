using System.Net.Http.Json;
using System.Text.Json;
using System.Text.Json.Serialization;
using GLMS.Contracts;
using Microsoft.AspNetCore.Mvc;

namespace GLMS.Web.Services;

public sealed class AccountApiClient(HttpClient httpClient) : IAccountApiClient
{
    private static readonly JsonSerializerOptions JsonOptions = CreateJsonOptions();

    public async Task RegisterAsync(RegisterAccountRequest request, CancellationToken cancellationToken)
    {
        using var response = await httpClient.PostAsJsonAsync("api/account/register", request, JsonOptions, cancellationToken);
        await EnsureSuccessAsync(response, cancellationToken);
    }

    public Task<AccountTokenResponse> LoginAsync(LoginAccountRequest request, CancellationToken cancellationToken) =>
        PostAsync<LoginAccountRequest, AccountTokenResponse>("api/account/login", request, cancellationToken);

    public Task<AccountTokenResponse> VerifyAsync(VerifyAccountRequest request, CancellationToken cancellationToken) =>
        PostAsync<VerifyAccountRequest, AccountTokenResponse>("api/account/verify", request, cancellationToken);

    public async Task ResendVerificationAsync(
        ResendAccountVerificationRequest request,
        CancellationToken cancellationToken)
    {
        using var response = await httpClient.PostAsJsonAsync(
            "api/account/resend-verification",
            request,
            JsonOptions,
            cancellationToken);
        await EnsureSuccessAsync(response, cancellationToken);
    }

    private async Task<TResponse> PostAsync<TRequest, TResponse>(
        string path,
        TRequest request,
        CancellationToken cancellationToken)
    {
        using var response = await httpClient.PostAsJsonAsync(path, request, JsonOptions, cancellationToken);
        await EnsureSuccessAsync(response, cancellationToken);
        return await response.Content.ReadFromJsonAsync<TResponse>(JsonOptions, cancellationToken)
            ?? throw new InvalidOperationException("The GLMS API returned an empty response.");
    }

    private static async Task EnsureSuccessAsync(HttpResponseMessage response, CancellationToken cancellationToken)
    {
        if (response.IsSuccessStatusCode)
        {
            return;
        }

        var problem = await response.Content.ReadFromJsonAsync<ProblemDetails>(JsonOptions, cancellationToken);
        throw new ApiClientException(
            response.StatusCode,
            problem?.Detail ?? problem?.Title ?? $"The GLMS API returned HTTP {(int)response.StatusCode}.");
    }

    private static JsonSerializerOptions CreateJsonOptions()
    {
        var options = new JsonSerializerOptions(JsonSerializerDefaults.Web);
        options.Converters.Add(new JsonStringEnumConverter());
        return options;
    }
}
