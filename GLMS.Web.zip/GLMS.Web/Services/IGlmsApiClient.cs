using GLMS.Contracts;
using GLMS.Web.Models;

namespace GLMS.Web.Services;

public interface IGlmsApiClient
{
    Task<DashboardResponse> GetDashboardAsync(CancellationToken cancellationToken);
    Task<IReadOnlyList<ClientResponse>> GetClientsAsync(CancellationToken cancellationToken);
    Task<ClientResponse> CreateClientAsync(CreateClientRequest request, CancellationToken cancellationToken);
    Task<IReadOnlyList<ContractResponse>> GetContractsAsync(ContractStatus? status, DateTime? fromDate, DateTime? toDate, CancellationToken cancellationToken);
    Task<ContractResponse> CreateContractAsync(CreateContractRequest request, CancellationToken cancellationToken);
    Task<DownloadedAgreement?> DownloadAgreementAsync(int id, CancellationToken cancellationToken);
    Task<IReadOnlyList<ServiceRequestResponse>> GetServiceRequestsAsync(CancellationToken cancellationToken);
    Task<ServiceRequestResponse> CreateServiceRequestAsync(CreateServiceRequestRequest request, CancellationToken cancellationToken);
    Task<ExchangeRateResponse> GetCurrentRateAsync(CancellationToken cancellationToken);
}

public sealed record DownloadedAgreement(byte[] Content, string FileName);
