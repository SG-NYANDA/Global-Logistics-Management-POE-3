using System.Security.Claims;

namespace GLMS.Web.Services;

public sealed class ApiAuthorizationHandler(
    IHttpContextAccessor httpContextAccessor) : DelegatingHandler
{
    public const string AccessTokenClaim = "glms_api_access_token";

    protected override Task<HttpResponseMessage> SendAsync(
        HttpRequestMessage request,
        CancellationToken cancellationToken)
    {
        var token = httpContextAccessor.HttpContext?.User.FindFirstValue(AccessTokenClaim);
        if (!string.IsNullOrWhiteSpace(token))
        {
            request.Headers.Authorization = new System.Net.Http.Headers.AuthenticationHeaderValue("Bearer", token);
        }

        return base.SendAsync(request, cancellationToken);
    }
}
