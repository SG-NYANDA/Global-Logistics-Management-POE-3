using System.Net;

namespace GLMS.Web.Services;

public sealed class ApiClientException(
    HttpStatusCode statusCode,
    string message) : Exception(message)
{
    public HttpStatusCode StatusCode { get; } = statusCode;
}
