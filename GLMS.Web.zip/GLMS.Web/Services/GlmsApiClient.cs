using System.Globalization;
using System.Net;
using System.Net.Http.Json;
using System.Text.Json;
using System.Text.Json.Serialization;
using GLMS.Contracts;
using GLMS.Web.Models;
using Microsoft.AspNetCore.Mvc;

namespace GLMS.Web.Services;

public sealed class GlmsApiClient(HttpClient httpClient) : IGlmsApiClient
{
    private static readonly JsonSerializerOptions JsonOptions = CreateJsonOptions();

    public Task<DashboardResponse> GetDashboardAsync(CancellationToken cancellationToken) =>
        GetAsync<DashboardResponse>("api/dashboard", cancellationToken);

    public Task<IReadOnlyList<ClientResponse>> GetClientsAsync(CancellationToken cancellationToken) =>
        GetAsync<IReadOnlyList<ClientResponse>>("api/clients", cancellationToken);

    public Task<ClientResponse> CreateClientAsync(CreateClientRequest request, CancellationToken cancellationToken) =>
        PostAsync<CreateClientRequest, ClientResponse>("api/clients", request, cancellationToken);

    public Task<IReadOnlyList<ContractResponse>> GetContractsAsync(
        ContractStatus? status,
        DateTime? fromDate,
        DateTime? toDate,
        CancellationToken cancellationToken)
    {
        var query = new List<string>();
        if (status.HasValue)
        {
            query.Add($"status={Uri.EscapeDataString(status.Value.ToString())}");
        }

        if (fromDate.HasValue)
        {
            query.Add($"fromDate={Uri.EscapeDataString(fromDate.Value.ToString("yyyy-MM-dd", CultureInfo.InvariantCulture))}");
        }

        if (toDate.HasValue)
        {
            query.Add($"toDate={Uri.EscapeDataString(toDate.Value.ToString("yyyy-MM-dd", CultureInfo.InvariantCulture))}");
        }

        var path = "api/contracts" + (query.Count == 0 ? string.Empty : $"?{string.Join("&", query)}");
        return GetAsync<IReadOnlyList<ContractResponse>>(path, cancellationToken);
    }

    public async Task<ContractResponse> CreateContractAsync(
        CreateContractRequest request,
        CancellationToken cancellationToken)
    {
        using var content = new MultipartFormDataContent();
        content.Add(new StringContent(request.Reference), nameof(request.Reference));
        content.Add(new StringContent(request.ServiceLevel), nameof(request.ServiceLevel));
        content.Add(new StringContent(request.StartDate.ToString("yyyy-MM-dd", CultureInfo.InvariantCulture)), nameof(request.StartDate));
        content.Add(new StringContent(request.EndDate.ToString("yyyy-MM-dd", CultureInfo.InvariantCulture)), nameof(request.EndDate));
        content.Add(new StringContent(request.Status.ToString()), nameof(request.Status));
        content.Add(new StringContent(request.ClientId.ToString(CultureInfo.InvariantCulture)), nameof(request.ClientId));
        await using var stream = request.Agreement.OpenReadStream();
        using var file = new StreamContent(stream);
        file.Headers.ContentType = new System.Net.Http.Headers.MediaTypeHeaderValue("application/pdf");
        content.Add(file, nameof(request.Agreement), Path.GetFileName(request.Agreement.FileName));
        return await SendAsync<ContractResponse>(
            new HttpRequestMessage(HttpMethod.Post, "api/contracts") { Content = content },
            cancellationToken);
    }

    public async Task<DownloadedAgreement?> DownloadAgreementAsync(int id, CancellationToken cancellationToken)
    {
        using var response = await httpClient.GetAsync($"api/contracts/{id}/agreement", cancellationToken);
        if (response.StatusCode == HttpStatusCode.NotFound)
        {
            return null;
        }

        await EnsureSuccessAsync(response, cancellationToken);
        var content = await response.Content.ReadAsByteArrayAsync(cancellationToken);
        var fileName = response.Content.Headers.ContentDisposition?.FileNameStar
            ?? response.Content.Headers.ContentDisposition?.FileName
            ?? $"contract-{id}-agreement.pdf";
        return new DownloadedAgreement(content, fileName.Trim('"'));
    }

    public Task<IReadOnlyList<ServiceRequestResponse>> GetServiceRequestsAsync(CancellationToken cancellationToken) =>
        GetAsync<IReadOnlyList<ServiceRequestResponse>>("api/service-requests", cancellationToken);

    public Task<ServiceRequestResponse> CreateServiceRequestAsync(
        CreateServiceRequestRequest request,
        CancellationToken cancellationToken) =>
        PostAsync<CreateServiceRequestRequest, ServiceRequestResponse>("api/service-requests", request, cancellationToken);

    public Task<ExchangeRateResponse> GetCurrentRateAsync(CancellationToken cancellationToken) =>
        GetAsync<ExchangeRateResponse>("api/service-requests/current-rate", cancellationToken);

    private async Task<TResponse> GetAsync<TResponse>(string path, CancellationToken cancellationToken)
    {
        using var response = await httpClient.GetAsync(path, cancellationToken);
        await EnsureSuccessAsync(response, cancellationToken);
        return await response.Content.ReadFromJsonAsync<TResponse>(JsonOptions, cancellationToken)
            ?? throw new InvalidOperationException("The GLMS API returned an empty response.");
    }

    private async Task<TResponse> PostAsync<TRequest, TResponse>(
        string path,
        TRequest request,
        CancellationToken cancellationToken)
    {
        using var response = await httpClient.PostAsJsonAsync(path, request, JsonOptions, cancellationToken);
        await EnsureSuccessAsync(response, cancellationToken);
        return await response.Content.ReadFromJsonAsync<TResponse>(JsonOptions, cancellationToken)
            ?? throw new InvalidOperationException("The GLMS API returned an empty response.");
    }

    private async Task<TResponse> SendAsync<TResponse>(
        HttpRequestMessage request,
        CancellationToken cancellationToken)
    {
        using (request)
        using (var response = await httpClient.SendAsync(request, cancellationToken))
        {
            await EnsureSuccessAsync(response, cancellationToken);
            return await response.Content.ReadFromJsonAsync<TResponse>(JsonOptions, cancellationToken)
                ?? throw new InvalidOperationException("The GLMS API returned an empty response.");
        }
    }

    private static async Task EnsureSuccessAsync(HttpResponseMessage response, CancellationToken cancellationToken)
    {
        if (response.IsSuccessStatusCode)
        {
            return;
        }

        var problem = await response.Content.ReadFromJsonAsync<ProblemDetails>(JsonOptions, cancellationToken);
        throw new ApiClientException(
            response.StatusCode,
            problem?.Detail ?? problem?.Title ?? $"The GLMS API returned HTTP {(int)response.StatusCode}.");
    }

    private static JsonSerializerOptions CreateJsonOptions()
    {
        var options = new JsonSerializerOptions(JsonSerializerDefaults.Web);
        options.Converters.Add(new JsonStringEnumConverter());
        return options;
    }
}
