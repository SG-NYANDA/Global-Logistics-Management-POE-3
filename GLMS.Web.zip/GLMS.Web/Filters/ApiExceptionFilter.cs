using System.Net;
using GLMS.Web.Models;
using GLMS.Web.Services;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Mvc.ModelBinding;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
using Microsoft.AspNetCore.Mvc.ViewFeatures;

namespace GLMS.Web.Filters;

public sealed class ApiExceptionFilter(
    ILogger<ApiExceptionFilter> logger) : IAsyncExceptionFilter
{
    public async Task OnExceptionAsync(ExceptionContext context)
    {
        if (context.Exception is ApiClientException { StatusCode: HttpStatusCode.Unauthorized })
        {
            await context.HttpContext.SignOutAsync();
            context.Result = new RedirectToActionResult("Login", "Account", null);
            context.ExceptionHandled = true;
            return;
        }

        if (context.Exception is OperationCanceledException
            && context.HttpContext.RequestAborted.IsCancellationRequested)
        {
            return;
        }

        if (context.Exception is not (ApiClientException or HttpRequestException or TaskCanceledException))
        {
            return;
        }

        logger.LogError(context.Exception, "The MVC client could not complete its request to the GLMS API");
        var viewData = new ViewDataDictionary<ApiUnavailableViewModel>(
            new EmptyModelMetadataProvider(),
            context.ModelState)
        {
            Model = new ApiUnavailableViewModel("The GLMS API is currently unavailable. Please try again shortly.")
        };
        context.Result = new ViewResult
        {
            ViewName = "Unavailable",
            ViewData = viewData,
            StatusCode = StatusCodes.Status503ServiceUnavailable
        };
        context.ExceptionHandled = true;
    }
}
